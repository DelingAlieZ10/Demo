// JavaScript Document
var html ='<div id="productlogo"><p>';
html +='<img id="tmp_psf" src="http://www.capcom.co.jp/common/logo/tmp/psf_b.png" height="28" />';
html +='<img src="http://www.capcom.co.jp/common/logo/tmp/ps4_b.png" height="17" />';
html +='<img src="http://www.capcom.co.jp/common/logo/tmp/xboxone_c_b.png" height="27" />';
html +='<img src="http://www.capcom.co.jp/common/logo/tmp/windows10_b.png" height="24" />';
html +='<img src="http://www.capcom.co.jp/common/logo/tmp/steam_b.png" height="24" />';
html +='</p></div>';
html += '<p id="copyright01">Images represent a game still in development.<br><img src="http://www.capcom.co.jp/common/images/hard_ps.gif" height="12" alt="PlayStation family logo mark">"PlayStation"  and<img src="http://www.capcom.co.jp/common/images/hard_ps4.gif" height="12" alt="PlayStation 4 logo">are registered trademarks or trademarks of Sony Interactive Entertainment Inc.<br>&copy;Valve Corporation. Steam and the Steam logo are trademarks and/or registered trademarks of Valve Corporation in the U.S. and/or other countries.</p>';
document.write(html);