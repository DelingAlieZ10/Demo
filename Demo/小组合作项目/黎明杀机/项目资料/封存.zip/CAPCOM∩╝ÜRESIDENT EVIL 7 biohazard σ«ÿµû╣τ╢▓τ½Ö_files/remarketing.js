// JavaScript Document

var rmk_label = "sZz3CO-qjGcQzNSZ2wM";

var html_rmk = '<script type="text/javascript">/* <![CDATA[ */';
html_rmk += 'var google_conversion_id = 996567628;';
html_rmk += 'var google_conversion_label = "'+ rmk_label +'";';
html_rmk += 'var google_custom_params = window.google_tag_params;';
html_rmk += 'var google_remarketing_only = true;';
html_rmk += '/* ]]> */</script>';
html_rmk += '<div style="display:none;"><script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script></div>';
html_rmk += '<noscript>';
html_rmk += '<div style="display:inline;"> <img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/996567628/?value=0&amp;label='+ rmk_label +'&amp;guid=ON&amp;script=0"/></div>';
html_rmk += '</noscript>';
document.write(html_rmk);
